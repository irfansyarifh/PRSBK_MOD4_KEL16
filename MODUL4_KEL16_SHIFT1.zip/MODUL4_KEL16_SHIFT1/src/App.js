//import logo from './logo.svg';
import React from "react";
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Counter from './learn-useState/Counter';
import Effect from './learn-useEffect/Index';
import Context from './learn-useContext/Index';
import ReduceAndRef from './learn-useReducerRef/Index';
import "bootstrap/dist/css/bootstrap.min.css";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import NavDropdown from "react-bootstrap/NavDropdown";

function App() {
  return (
    <Router>
    <div className="App-header">
    <Navbar bg="light" expand="lg">
  <Navbar.Brand href="#home">KELOMPOK 16</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="mr-auto">
      <Nav.Link href="/">Use State</Nav.Link>
      <Nav.Link href="/effect">Use Effect</Nav.Link>
      <Nav.Link href="/context">Use Context</Nav.Link>
      <Nav.Link href="/ReduceAndRef">Reduce And Ref</Nav.Link>
      <NavDropdown title="About" id="basic-nav-dropdown">
        <NavDropdown.Item href="https://www.instagram.com/umi_khoiryatin">Umi Khoiryatin</NavDropdown.Item>
        <NavDropdown.Item href="https://www.instagram.com/mirfansyarifh">M Irfan Syarif H</NavDropdown.Item>
      </NavDropdown>
    </Nav>
  </Navbar.Collapse>
</Navbar>
      <Switch>
        <Route path="/" exact component={Counter}/>
        <Route path="/effect" exact component={Effect}/>
        <Route path="/context" exact component={Context}/>
        <Route path="/ReduceAndRef" exact component={ReduceAndRef}/>
      </Switch>
      </div>
    </Router>

  );
}

export default App;
